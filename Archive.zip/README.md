# Facial Recognition Music

Kim, Mike, and Brett

Please use Firefox to access our project at http://bretthartman.net/facial-recognition